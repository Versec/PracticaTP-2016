package com.gomez_juan_lopez_javier.instructions.conditions;

import com.gomez_juan_lopez_javier.LexicalParser;
import com.gomez_juan_lopez_javier.terms.Term;

public class LessEq extends Condition {

	@Override
	protected Condition parseOp(Term t1, String op, Term t2, LexicalParser parser) {
		// TODO Auto-generated method stub
		return null;
	}

}

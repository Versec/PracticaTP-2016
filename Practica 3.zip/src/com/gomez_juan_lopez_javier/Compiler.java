package com.gomez_juan_lopez_javier;

public class Compiler {

	public Compiler() {
		// TODO Auto-generated constructor stub
	}

}

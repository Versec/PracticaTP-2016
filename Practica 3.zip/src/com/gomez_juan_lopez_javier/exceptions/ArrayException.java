package com.gomez_juan_lopez_javier.exceptions;

public class ArrayException extends Exception {
	
	public ArrayException(){
		
	}

}

package com.gomez_juan_lopez_javier.exceptions;

public class LexicalAnalysisException extends Exception {

}
